# Heroku Marketing Cloud API Demo

 A simple POC of Salesforce Marketing Cloud API using Heroku


For more information:

- [@leafarhz](https://twitter.com/leafarhz)
- [Rafael Hernandez](https://www.linkedin.com/in/leafarhz/)

